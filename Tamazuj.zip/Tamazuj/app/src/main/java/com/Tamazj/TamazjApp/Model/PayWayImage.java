package com.Tamazj.TamazjApp.Model;

public class PayWayImage {

    private int imgResource;

    public PayWayImage(int imgResource) {
        this.imgResource = imgResource;
    }

    public int getImgResource() {
        return imgResource;
    }

    public void setImgResource(int imgResource) {
        this.imgResource = imgResource;
    }
}
